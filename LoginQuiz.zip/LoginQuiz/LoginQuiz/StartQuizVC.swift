//
//  StartQuizVC.swift
//  LoginQuiz
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class StartQuizVC: UIViewController {
   
    var timer : Timer!
    var seconds = 10
    var i = 1
    var obj = Question1()
    
    var answer = ""
    var correctAnswer = ""
    var countwrongAnswer:Int = 0
    var countcorrectAnswer: Int = 0
    var unattemptedAnswer: Int = 0
    
    @IBOutlet weak var labelTimer: UILabel!
    @IBOutlet weak var lblQuestionNo: UIButton!
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var btnAnswer1: UIButton!
    @IBOutlet weak var btnAnswer2: UIButton!
    @IBOutlet weak var btnAnswer3: UIButton!
    
  //  @IBOutlet weak var btnAnswer4: UIButton!
   // @IBOutlet weak var btnCorrectAnswer: UIButton!
    @IBOutlet weak var btnNext: UIButton!
    
    func getData()
    {
        seconds = 10
          runTimer()
        // print("get data i value \(i) ")
        lblQuestionNo.setTitle("\(i)", for: .normal)
        lblQuestion.text = ("\(obj.dictquestion[i]![0])")
        btnAnswer1.setTitle("\(obj.dictanswers[i]![0])", for: .normal)
        btnAnswer2.setTitle("\(obj.dictanswers[i]![1])", for: .normal)
        btnAnswer3.setTitle("\(obj.dictanswers[i]![2])", for: .normal)
        correctAnswer = obj.dictquestion[i]![1]
        
    }
    
    func showScore()
    {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "Stat") as! Stat
        vc.correct = countcorrectAnswer
        vc.wrong = countwrongAnswer
        vc.unattempted = unattemptedAnswer
        self.present(vc, animated: true, completion: nil)
        
        print("correct answer :  \(countcorrectAnswer)")
        print("wrong answer : \(countwrongAnswer)")
        print("unattempted : \(unattemptedAnswer)")
        
    }
    
    
    @objc func counter ()
    {
        
        seconds -= 1
        labelTimer.text = String(seconds)
        if (seconds == 0 )
        {
            if(i <= obj.dictquestion.count)
            {
                timer.invalidate()
                skipped()
                
            }
            else
            {
                showScore()
            }
            
        }
    }
    
    
    
    @IBAction func actionBtn1pressed(_ sender: UIButton)
    {
        btnAnswer1.isEnabled = false
        btnAnswer2.isEnabled = false
        btnAnswer3.isEnabled = false
        //  print(btnAnswer1.titleLabel?.text)
        answer = (btnAnswer1.titleLabel?.text!)!
        if  (correctAnswer ==  btnAnswer1.titleLabel?.text)
         {
            countcorrectAnswer = countcorrectAnswer + 1
            print("i got right answer")
        }
        else
        {
            countwrongAnswer = countwrongAnswer + 1
            print("wrong answer")
        }
    }
    
    
    
    @IBAction func actionBtn2pressed(_ sender: UIButton)
    {
        btnAnswer1.isEnabled = false
        btnAnswer2.isEnabled = false
        btnAnswer3.isEnabled = false
        //print(btnAnswer2.titleLabel?.text)
        answer = (btnAnswer2.titleLabel?.text)!
       // print(answer)
        if  (correctAnswer ==  btnAnswer2.titleLabel?.text)
        {
            countcorrectAnswer = countcorrectAnswer + 1
            print(" 2   i got right answer")
        }
        else
        {
            countwrongAnswer = countwrongAnswer + 1
            print("  2    wrong answer")
        }
        
        
    }
    
    
    @IBAction func actionBtn3pressed(_ sender: UIButton)
    {
        btnAnswer1.isEnabled = false
        btnAnswer2.isEnabled = false
        btnAnswer3.isEnabled = false
       // print(btnAnswer3.titleLabel?.text )
        answer = (btnAnswer3.titleLabel?.text)!
       // print(answer)
        if  (correctAnswer ==  btnAnswer3.titleLabel?.text)
        {
            countcorrectAnswer = countcorrectAnswer + 1
            print("3   i got right answer")
        }
        else
        {
            countwrongAnswer = countwrongAnswer + 1
            print(" 3    wrong answer")
        }
        
    }
    
    
    @IBAction func actionButtonNext(_ sender: UIButton)
    {
        skipped()
     
    }//actionButtonNexts
    
    
    func resetAllButton()
    {
        btnAnswer1.isEnabled = true
        btnAnswer2.isEnabled = true
        btnAnswer3.isEnabled = true
        answer = ""
 
    
    }
    
    

    func skipped()
    {
        if(answer.isEmpty)
        {
            print("unatttempted")
            unattemptedAnswer = unattemptedAnswer + 1
        }
        i = i + 1
        if i <= obj.dictquestion.count
        {
            resetAllButton()
            getData()
            timer.invalidate()
            //  runTimer()
        }
        else
        {
            //  print("question finish")
          showScore()
           
    }
        
    }
        
        
        
        
        
    func runTimer()
    {
    timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(StartQuizVC.counter), userInfo: nil, repeats: true)
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getData()
        

    }


}
  



