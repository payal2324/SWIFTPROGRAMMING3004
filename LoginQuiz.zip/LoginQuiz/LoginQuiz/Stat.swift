//
//  Statistics.swift
//  LoginQuiz
//
//  Created by MacStudent on 2017-10-27.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class Stat: UIViewController {
    
    @IBOutlet weak var lblCorrect: UILabel!
    @IBOutlet weak var lblWrong: UILabel!
    @IBOutlet weak var lblUnattempted: UILabel!
  
    @IBOutlet weak var lblHome: UIButton!
    @IBOutlet weak var lblStatistics: UILabel!
   
    @IBOutlet weak var lblcorrectvalue: UILabel!
    @IBOutlet weak var lblunattemptedvalue: UILabel!
    @IBOutlet weak var lblwrongvalue: UILabel!
   
    var correct : Int!
    var wrong : Int!
    var unattempted : Int!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblcorrectvalue.text = String(correct)
        lblwrongvalue.text =  String(wrong)
        lblunattemptedvalue.text =  String(unattempted)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func actionlblHome(_ sender: UIButton) {
        
    }
    

}

