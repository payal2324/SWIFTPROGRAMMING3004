//
//  DashBoardVC.swift
//  LoginQuiz
//
//  Created by MacStudent on 2017-10-23.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class DashBoardVC: UIViewController {

    @IBOutlet weak var btnLogout: UIButton!
    @IBOutlet weak var lblTextView: UITextView!
    
    @IBOutlet weak var btnStart: UIButton!
    @IBOutlet weak var btnInstructions: UIButton!
    @IBOutlet weak var btnStatistics: UIButton!
    
    var email: String!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        print(email)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func actionbtnLogOut(_ sender: UIButton) {
        
       // self.dismiss(animated: true, completion: nil)
    }
    @IBAction func actionBtnStart(_ sender: UIButton)  {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let sq = storyBoard.instantiateViewController(withIdentifier: "StartQuizVC") as! StartQuizVC
        self.present(sq, animated: true, completion: nil)
    }
    
   
    @IBAction func actionBtnInstructions(_ sender: UIButton)
    {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "InstructionsVC") as! InstructionsVC
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func actionBtnStatistics(_ sender: UIButton)
    {
        
//        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "Stat") as! Stat
//        self.present(vc, animated: true, completion: nil)
    }
    
        
    }
    
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


