//
//  Question1.swift
//  LoginQuiz
//
//  Created by MacStudent on 2017-10-27.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation
class Question1
{
    var correct  = 0
    var wrong = 0

var i = 1
var dictquestion = [Int: Array<String>]()
var dictanswers = [Int:Array<String>]()
//dictquestion[1] = ["who is harry?","harry Potter"]
 init()
 {
    
    dictquestion = [
    1:["Who is known as Father Of Computers?","Charles Babbage"],
    2:["What is the full form of RAM?", "Random Access Memory"],
    3:["Which of the following is known as Brain of Computer?", "Central Processing Unit"],
    4:["What is the full form of USB ?", "Universal Serial Bus"],
    5:["How many bytes are in a Kilobyte (KB) ?","1024 Bytes"],
    6:["Of what material computer's IC chips are made of ?","Silicon"],
    7:["What is the full Form of Virus ?","Vital Important Resources Under Siege"],
    8:["A blog is also known as _______ ?","Weblog"],
    9:[" What is the full form of WiFi ? ","Wireless Fidelity"],
    10:["Who is the founder of Facebook ? ","Mark Zuckerberg"]]
    print(dictquestion.count)
    
    dictanswers = [
    1:["Charles Babbage","Mark Zuckerberg","Steve Jobs"],
    2:["Read Only Memory","Random Access Memory","Read Write Memory"],
    3:["Arithmetic and Logic Unit","Control Processing Unit","Central Processing Unit"],
    4:["Universal Serial Bus","Universal Storage Bus","Union Serial Bus"],
    5:["1024 Bytes","1224 Bytes", "1084 Bytes"],
    6:["Aluminium","Phosphor","Silicon"],
    7:["Very Important Resources Under Security","Vital Important Resources Under Siege", "Vital Imergency Resources Under Safety"],
    8:["Weblog","Monoblog","Multiblog"],
    9:["Wireless Fidelity","Wired Fidelity", "Worldwide Fidelity"],
    10:["Mark Zuckerberg","Charles Babbage","Steve Jobs" ]
    ]
    
    
    }
    
    func code()
    {
        
   
for i in 1...dictquestion.count
{
    print("******")
    print("Qno \(i)")
    print("Q: \(dictquestion[i]![0])")
    print("ans1:\(dictanswers[i]![0])")
    print("ans2:\(dictanswers[i]![1])")
    print("ans3:\(dictanswers[i]![2])")
    if (dictquestion[i]![1] == dictanswers[i]![1])
    {
        print("correct Answer")
        correct = correct + 1
        
    }
    else
    {
        print ("wrong answer")
        wrong = wrong + 1
        
    }
    
}

print("c \(correct)")
print("w \(wrong)")
    }
}
