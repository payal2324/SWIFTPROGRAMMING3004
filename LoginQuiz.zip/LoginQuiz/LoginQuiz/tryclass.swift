//
//  Question.swift
//  LoginQuiz
//
//  Created by MacStudent on 2017-10-25.
//  Copyright © 2017 MacStudent. All rights reserved.
//

//import Foundation
//class tryclass {
//    
//    var questionNo : Int!
//    var question : String!
//    var answer1: String!
//    var answer2: String!
//    var answer3: String!
//    var answer4: String!
//    var correctAnswer: String!
////  static var ArrayQuestion = [Question]()
//
//   static  var arrayQue = [Question]()
//    
//    init()
//    {
//        questionNo = -1
//        question = ""
//        answer1 = ""
//        answer2 = ""
//        answer3 = ""
//        answer4 = ""
//        correctAnswer = ""
//        
//    }
//    
//    init( questionNo: Int, question: String , ans1:String, ans2:String , ans3:String, ans4:String , correctAnswer: String )
//    {
//        self.questionNo = questionNo
//        self.question = question
//        self.answer1 = ans1
//        self.answer2 = ans2
//        self.answer3 = ans3
//        self.answer4 = ans4
//        self.correctAnswer = correctAnswer
//        
//    }
//    
//   static var q1 = Question( questionNo: 1, question: "what is your name?" , ans1:"a1", ans2:"a2" , ans3:"a3", ans4:"a4" , correctAnswer: "a1")
//    static var q2 = Question( questionNo: 2, question: "what?" , ans1:"b1", ans2:"b2" , ans3:"b3", ans4:"b4" , correctAnswer: "b1")
//    static var q3 = Question( questionNo: 3, question: "who?" , ans1:"c1", ans2:"c2" , ans3:"c3", ans4:"c4" , correctAnswer: "c1")
//    
//    
//    
//    //ArrayQuestion[0] = q1
//    
//    
//
////
////   static func Add() {
////
////        arrayQue.append(q1)
////        arrayQue.append(q2)
////        arrayQue.append(q3)
////        arrayQue.append(q1)
////        arrayQue.append(q1)
////        arrayQue.append(q1)
////        arrayQue.append(q1)
////        arrayQue.append(q1)
////
////
////
////
////    }
//    
//     static var temp = [q1,q2,q3]
//    
//    
//    func display()
//    {
//        print(Question.q1.answer1)
//    }
//    
//    static func retQue () -> [Question] {
//        
//        return temp
//        
//    }
//    
//}
//    
//    
//    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    var dictRoot = [Int: Dictionary<String, Any>]()         //1  : dictionary of   "ques" , answers
//    var dictOfQuestion = [String:Array<String>]()
//    var array1 = [String]()
//
  
    
    
    
//
//    func getQuestions(question: Int)
//   {
//    if self.dictRoot[1] != nil{
//       self.dictRoot[dictOfQuestion]!
//    }
//
//    }
//
 



