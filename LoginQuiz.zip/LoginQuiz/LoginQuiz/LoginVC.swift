//
//  ViewController.swift
//  LoginQuiz
//
//  Created by MacStudent on 2017-10-23.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    var myUserDefault = UserDefaults.standard
    
    @IBOutlet weak var tfUsername: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var lblRememberMe: UILabel!
    @IBOutlet weak var mySwitch: UISwitch!
   
    @IBAction func mySwitch(_ sender: UISwitch) {
    }
  
    override func viewDidLoad() {
        super.viewDidLoad()
// Do any additional setup after loading the view, typically from a nib.
         if let username = myUserDefault.value(forKey: "username")
         { tfUsername.text = username as? String
        }
        if let userpassword = myUserDefault.value(forKey: "userpassword")
        {
            tfPassword.text = userpassword as? String
        }
  
    
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    func loginSuccessful()
    {
        let alert = UIAlertController.init(title: "Message", message: "Welcome to Quiz", preferredStyle: .alert)
        let action1 = UIAlertAction.init(title: "OK", style: .default, handler:{ action in self.segue()})
        alert.addAction(action1)
        self.present(alert, animated: true, completion: nil)
        btnLogin.setTitleColor(UIColor.blue, for: UIControlState.selected)
        
    }
    
    func loginFailed()
    {
        let alert = UIAlertController.init(title: "Message", message: "Wrong Username or Password", preferredStyle: .alert)
        let action1 = UIAlertAction.init(title: "Retry", style: .destructive, handler: nil)
        alert.addAction(action1)
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func ActionBtnLogin(_ sender: UIButton)
    {
        if mySwitch.isOn{
            
         if (tfUsername.text == "payal") && (tfPassword.text == "12345")
             {
            loginSuccessful()
             }
   
        else{
            loginFailed()
            }
        }
            
            
    else if ((tfUsername.text == "payal") && (tfPassword.text == "12345"))
        {
            loginSuccessful()
            tfUsername.text = " "
            tfPassword.text = " "
        }
        else{
            loginFailed()
            
            }
        
    }
    

    
  func segue()
  {
    
    let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
    let vc = storyBoard.instantiateViewController(withIdentifier: "DashBoardVC") as! DashBoardVC
    
    vc.email = tfUsername.text
    self.present(vc, animated: true, completion: nil)
    
    }
    
    

}
